#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np 
import pylab as plt
import matplotlib.image as mpimg
import cv2


def imhist(im):
  # calculates normalized histogram of an image
	m, n = im.shape
	h = [0.0] * 256
	for i in range(m):
		for j in range(n):
			h[im[i, j]]+=1
	return np.array(h)/(m*n)

def cumsum(h):
	# finds cumulative sum of a numpy array, list
	return [sum(h[:i+1]) for i in range(len(h))]

def histeq(im):
	#calculate Histogram
	h = imhist(im)
	cdf = np.array(cumsum(h)) #cumulative distribution function
	sk = np.uint8(255 * cdf) #finding transfer function values
	s1, s2 = im.shape
	Y = np.zeros_like(im)
	# applying transfered values for each pixels
	for i in range(0, s1):
		for j in range(0, s2):
			Y[i, j] = sk[im[i, j]]
	H = imhist(Y)
	#return transformed image, original and new istogram, 
	# and transform function
	return Y , h, H, sk

#================================================
#=========Main program===========================

img = cv2.imread("1.jpg")

if img.ndim > 1:
    (rows, cols, c) = img.shape
else:
    (rows, cols) = img.shape
    c=1
#img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

new_img = np.zeros((rows, cols, c), np.uint8)
# Any good way???

for i in range(c):
    result, h, new_h, sk = histeq(img[:,:,i])
    new_img[:,:,i] = result
    
#gaussianResult = cv2.GaussianBlur(new_img,(3,3),1.5)

if new_img.ndim > 1:
    (rows, cols, c) = new_img.shape
else:
    (rows, cols) = new_img.shape
    c=1
#im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)

res = np.zeros((rows, cols, c), np.uint8)
for i in range(c):
    I = np.reshape(new_img[:,:,i], [rows, cols])
    I = np.asarray(I, np.float32)
    filtered_image_OpenCV = cv2.bilateralFilter(I, 5, 12.0, 16.0)
    #filtered_image_own = bilateral_filter_own(I, 5, 12.0, 16.0)
    res[:,:,i] = np.asarray(filtered_image_OpenCV, np.uint8)

ims = cv2.resize(res, (400, 720))                
cv2.imshow("output", ims)                     
cv2.waitKey(0)     



# In[ ]:




